package com.example.myapplication.Models

class UserLogin internal constructor(val email: String, val password: String)